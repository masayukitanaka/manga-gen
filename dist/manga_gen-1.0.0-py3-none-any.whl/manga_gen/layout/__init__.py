"""Layout computation modules."""
